const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const app = express();
app.set('view engine','ejs');
app.use(bodyParser.urlencoded({extended:true}));

// Linking static files
app.use(express.static(__dirname + "/public"));

const connection = mysql.createConnection({
	host: 'localhost',
	user: 'root',
	database: 'join_us'
});

// app.get("/",(req,res)=>{
// 	const qry = 'SELECT COUNT(*) AS Count FROM users;';
// 	connection.query(qry, function(err,result){
// 		if(err)	throw err;
// 		// console.log(result[0].Count);
// 		const count = result[0].Count;
// 		res.send(`We have ${count} number of users in our database!`);
// 	});
// 	// We cannot guarentee that the callback will be executed before the other statment. Thus we put the res.send() inside the call backfunction itself to keep the execution order safe.
// });

app.get("/",(req,res)=>{
	const qry = 'SELECT COUNT(*) AS Count FROM users;';
	connection.query(qry, function(err,result){
		if(err)	throw err;
		// console.log(result[0].Count);
		const count = result[0].Count;
	
	// express automatically searches for /views/home.ejs
	res.render("home",{count:count});
	});
});

app.post("/register", (req,res)=>{
	
	// console.log("POST request made: " + req.body.email);
	// console.log(req.body);
	// res.send(`Request made by user with email ${req.body.email}`);
	const person = {
		email: req.body.email
	}
	const qry = "INSERT INTO users SET ?";
	connection.query(qry,person,(err,result)=>{
		if(err)	throw err;
		res.redirect("/");
	})
});

app.get("/home",function(req,res){
	// We can have only on res.send() for a particular route
	res.send("<h2 style='color:red'>Hello World!</h2>");
});

app.get("/random", (req,res)=>{
	const random = Math.trunc(Math.random()*10)+1;
	res.send(`The Random number is: ${random}`);
});

app.get("/joke",(req,res)=>{
	const joke = "I'd tell you a joke about UDP but you might not get it!";
	res.send(joke);
});

app.listen(3000, function(){
	console.log("Join us app listening on port 3000...");
});
