var faker = require('faker');

console.log('Fake Email: ' + faker.internet.email());
console.log('Fake Past Date: ' + faker.date.past());

console.log('Fake Address: ' + faker.address.city());
console.log('Complete fake address: ' + faker.address.streetAddress() + ', ' + faker.address.streetName() + ', ' + faker.address.city() + ', ' + faker.address.state());

function generateAddress(num){
	console.log('Generating ' + num + ' Addresses...');
	// Generate num random fake addresses
	for(var i=0 ; i<num ; i++){
			console.log('Address ' + (i+1) + ': ' + faker.address.streetAddress() + ', '  + faker.address.city() + ', ' + faker.address.state());
	}
	return ;
}

// Generate 3 Addresses
generateAddress(3);


// Generate 5 Addresses
generateAddress(5);

