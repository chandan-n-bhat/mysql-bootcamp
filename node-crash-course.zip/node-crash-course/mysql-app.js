var mysql = require('mysql');
var faker = require('faker');

var conn = mysql.createConnection({
	host : 'localhost',
	user : 'root',
	database: 'join_us'
})


function output(error,result,fields){
	if(error){
		throw error;
	}
	console.log('The output is: ' + result[0]['NOW()']);
}
function output2(error,result,fields){
	if(error){
		throw error;
	}
	console.log('The output is: ' + result[0]['Current Date']);
}
var query1 = 'SELECT NOW();';
var query2 = 'SELECT NOW() AS \'Current Date\';';
var query3 = 'SELECT CURTIME() AS time, CURDATE() AS date, NOW() AS datetime;';

conn.query(query1,output);
conn.query(query2,output2);

conn.query(query3, function (error, result,fields){
	if(error)	throw error;
	out = result[0];
	console.log('Output is:');
	console.log('Time: ' + out.time);
	console.log('Date: ' + out.date.toString());
	console.log('Date Time: ' + out.datetime.toString());
	return ;
})

console.log('Create Statements');
/* // Run only once
// Create table users
create_query = 'CREATE TABLE users(\
	email  VARCHAR(255)	 PRIMARY KEY,\
	created_at	TIMESTAMP  DEFAULT NOW()\
);';

conn.query(create_query, function(error,result,fields){
	if(error)	throw error;
	console.log(result);
})
*/
/*
console.log('Insert Statements')
insert_query = 'INSERT INTO users(email) VALUES(\'chandan@gmail.com\'),(\'harshitha@outlook.com\');';
conn.query(insert_query,function(error,result,fields){
	if(error)	throw error;
	console.log(result);
	return ;
})
*/

// Correct way to insert i.e. dynamically
// var insert_data = {email:'nagaraj@hotmail.com'};
// dynamic_insert_query = 'INSERT INTO users SET ?';
// conn.query(dynamic_insert_query,insert_data, function(err,res,fields){
// 	if(err)	throw err;
// 	console.log(res);
// });

var insertData = {
	email: faker.internet.email().toString(),
	created_at: faker.date.past
}
var dyInsertQuery = 'INSERT INTO users SET ?';
var compiled = conn.query(dyInsertQuery,insertData, function(err,res,fields){
	if(err)	throw err;
	console.log(res);
})

console.log('#################SQL Equivalent of insert#################');
console.log(compiled.sql);
console.log('#################SQL Equivalent of insert#################');

select_query = 'SELECT * FROM users;';
conn.query(select_query,function(error,result,fields){
	if(error)	throw error;
	console.log(result);
})

// Find the number of users
// A very bad way would be to select all users and use length property of a javascript on the result
count_query = 'SELECT COUNT(*) AS count FROM users;';
conn.query(count_query,function(error,result,fields){
	if(error)	throw error;
	console.log('\nThe total users are: ' + result[0].count);
})


// Bulk Insertion

var bulkData = [];

var noOfEntries = 500;

for(var i=1 ; i<=500 ; i++){
	bulkData.push([
		faker.internet.email(),
		faker.date.past()
	])
}// 500 entries are ready
// console.log(bulkData);

var bulkInsertQuery = 'INSERT INTO users (email,created_at) VALUES ?';
var equivalentSql = conn.query(bulkInsertQuery,[bulkData],function(err,res,fields){
	if(err)	throw err;
	console.log(res);
})
console.log('#################SQL Equivalent of bulk insert#################');
console.log(equivalentSql.sql);
console.log('#################SQL Equivalent of bulk insert#################');

conn.end();