var mysql = require('mysql');

var conn = mysql.createConnection({
	host: 'localhost',
	user: 'root',
	database: 'join_us'
});

// Challenge 1: Earliest date the user joined
c1_query = 'SELECT created_at AS earliest_date FROM users ORDER BY created_at LIMIT 1;';
conn.query(c1_query,function(err,res,fields){
	if(err)	throw err;
	console.log('Earliest Date: ' + res[0].earliest_date);
})

// Challenge 2: Find Email Of The First (Earliest)User

conn.end()