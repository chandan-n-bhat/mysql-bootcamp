USE join_us;

-- Challenge 1: Find Earliest Date A User Joined

SELECT
    DATE_FORMAT(created_at,'%M %D %Y') AS earliest_date
FROM users
ORDER BY created_at
LIMIT 1;

-- Challenge 2: Find Email Of The First (Earliest)User
SELECT
    users.email AS 'User',
    users.created_at AS 'Join Date'
FROM users
ORDER BY created_at
LIMIT 1;

SELECT
    users.email AS 'User'
FROM users
WHERE created_at = (SELECT MIN(created_at) FROM users);

-- Challenge 3: Count Users According To The Month They Joined
# +-----------+-------+
# | month     | count |
# +-----------+-------+
# | November  |    51 |
# | January   |    49 |
# | May       |    48 |
# | December  |    47 |
# | July      |    46 |
# | June      |    43 |
# | April     |    41 |
# | October   |    41 |
# | September |    40 |
# | March     |    40 |
# | August    |    40 |
# | February  |    32 |
# +-----------+-------+

SELECT
    DATE_FORMAT(created_at,'%M') AS month,
    COUNT(*) AS count
FROM users
GROUP BY month;

SELECT
    DATE_FORMAT(created_at,'%M') AS month,
    COUNT(*) AS count
FROM users
GROUP BY month
ORDER BY DATE_FORMAT(created_at,'%m');

-- Challenge 4: Count Number of Users With Yahoo Emails

SELECT
    COUNT(*) AS 'Yahoo Users'
FROM users
WHERE users.email LIKE '%@yahoo.com';

-- Challenge 5: Calculate Total Number of Users for Each Email Host


    