// Node is a server environment based on javascript
// Command to execute: node filename.js
console.log("Hello World!!");